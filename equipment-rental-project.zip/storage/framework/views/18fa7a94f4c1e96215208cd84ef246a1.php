<?php $__env->startSection('styles'); ?>
    
    <style>
        .avatar-placeholder {
            width: 40px;
            height: 40px;
            background-color: var(--bs-primary);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 1.1rem;
            border-radius: 50%;
        }

        .action-dropdown .dropdown-menu {
            min-width: 200px;
            /* تم تعديل العرض قليلاً */
            border-radius: 0.5rem;
            box-shadow: 0 .5rem 1rem rgba(0, 0, 0, .15);
        }

        .action-dropdown .dropdown-item {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 0.5rem 1rem;
        }

        .action-dropdown .dropdown-item i {
            width: 18px;
            text-align: center;
            opacity: 0.7;
        }

        /* تم حذف Select2-related styles */
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="h3 mb-0 text-gray-800">إدارة المستخدمين</h1>
            <div>
                <a href="<?php echo e(route('admin.users.trash')); ?>" class="btn btn-outline-danger me-2">
                    <i class="fas fa-trash-alt"></i> سلة المحذوفات
                </a>
                <button class="btn btn-primary shadow-sm" data-bs-toggle="modal" data-bs-target="#createUserModal">
                    <i class="fas fa-user-plus fa-sm me-2"></i>إضافة مستخدم جديد
                </button>
            </div>
        </div>


        <?php echo $__env->make('partials.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

        <div class="card shadow">
            <div class="card-header py-3">
                <div class="d-flex flex-column flex-md-row justify-content-between align-items-center">
                    <h6 class="m-0 fw-bold text-primary mb-2 mb-md-0">
                        <i class="fas fa-users me-2"></i>قائمة المستخدمين (<?php echo e($users->total()); ?>)
                    </h6>
                    
                    <form action="<?php echo e(route('admin.users.index')); ?>" method="GET" class="d-flex flex-wrap"
                        style="max-width: 600px; width: 100%;">

                        <div class="input-group mb-2 mb-md-0 me-2" style="flex:1 1 250px;">
                            <input type="text" name="query" class="form-control" placeholder="ابحث بالاسم أو البريد..."
                                value="<?php echo e($query ?? ''); ?>">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>

                        <select name="status" class="form-select me-2 mb-2 mb-md-0" style="width:auto;" onchange="this.form.submit()">
                            <option value="all" <?php echo e(($status ?? 'all') == 'all' ? 'selected' : ''); ?>>كل الحالات</option>
                            <option value="active" <?php echo e(($status ?? '') == 'active' ? 'selected' : ''); ?>>نشط</option>
                            <option value="inactive" <?php echo e(($status ?? '') == 'inactive' ? 'selected' : ''); ?>>غير نشط</option>
                        </select>

                        <select name="role" class="form-select me-2 mb-2 mb-md-0" style="width:auto;" onchange="this.form.submit()">
                            <option value="all" <?php echo e(($role ?? 'all') == 'all' ? 'selected' : ''); ?>>كل الأدوار</option>
                            <option value="user" <?php echo e(($role ?? '') == 'user' ? 'selected' : ''); ?>>مستخدم</option>
                            <option value="admin" <?php echo e(($role ?? '') == 'admin' ? 'selected' : ''); ?>>مدير</option>
                        </select>

                        <?php if($query || ($status ?? 'all') !== 'all' || ($role ?? 'all') !== 'all'): ?>
                            <a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-secondary ms-2 mb-2 mb-md-0"
                                title="إلغاء البحث والفلاتر">
                                <i class="fas fa-times"></i>
                            </a>
                        <?php endif; ?>
                    </form>

                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>المستخدم</th>
                                <th>الدور</th> 
                                <th class="text-center">الحالة</th>
                                <th class="text-center">آخر تسجيل دخول</th>
                                <th class="text-center">الإجراءات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <div class="avatar-placeholder me-3">
                                                <span><?php echo e(mb_substr($user->first_name, 0, 1)); ?></span> 
                                            </div>
                                            <div>
                                                <div class="fw-bold"><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></div>
                                                
                                                <div class="text-muted small"><?php echo e($user->email); ?></div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        
                                        <?php if($user->role === 'admin'): ?>
                                            <span class="badge bg-danger">مدير</span>
                                        <?php else: ?>
                                            <span class="badge bg-primary">مستخدم</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center">
                                        <?php if($user->is_active): ?>
                                            <span class="badge bg-success">نشط</span>
                                        <?php else: ?>
                                            <span class="badge bg-warning text-dark">غير نشط</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center">
                                        
                                        <?php echo e($user->last_login_at ? $user->last_login_at->diffForHumans() : '-'); ?>

                                    </td>

                                    <td class="text-center">
                                        <div class="dropdown action-dropdown">
                                            <button class="btn btn-light btn-sm dropdown-toggle" type="button"
                                                data-bs-toggle="dropdown">إجراءات</button>
                                            <ul class="dropdown-menu dropdown-menu-end">
                                                <li>
                                                    <a class="dropdown-item" href="<?php echo e(route('admin.users.show', $user)); ?>">
                                                        <i class="fas fa-eye text-info"></i> عرض التفاصيل
                                                    </a>
                                                </li>
                                                
                                                <?php if($user->id !== 1 && auth()->id() !== $user->id): ?>
                                                    <?php if($user->is_active): ?>
                                                        <li><a class="dropdown-item" href="#" data-bs-toggle="modal"
                                                                data-bs-target="#deactivateUserModal<?php echo e($user->id); ?>"><i
                                                                    class="fas fa-times-circle text-warning"></i> تعطيل
                                                                المستخدم</a></li>
                                                    <?php else: ?>
                                                        <li><a class="dropdown-item" href="#"
                                                                onclick="event.preventDefault(); document.getElementById('activate-form-<?php echo e($user->id); ?>').submit();"><i
                                                                    class="fas fa-check-circle text-success"></i> تفعيل
                                                                المستخدم</a>
                                                            <form id="activate-form-<?php echo e($user->id); ?>"
                                                                action="<?php echo e(route('admin.users.activate', $user)); ?>"
                                                                method="POST" class="d-none"><?php echo csrf_field(); ?></form>
                                                        </li>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                                <li><a class="dropdown-item" href="#" data-bs-toggle="modal"
                                                        data-bs-target="#editUserModal<?php echo e($user->id); ?>"><i
                                                            class="fas fa-edit text-info"></i> تعديل المستخدم</a></li>
                                                <?php if(auth()->id() != $user->id && $user->id != 1): ?>
                                                    <li>
                                                        <hr class="dropdown-divider">
                                                    </li>
                                                    <li><a class="dropdown-item text-danger" href="#"
                                                            data-bs-toggle="modal"
                                                            data-bs-target="#deleteUserModal<?php echo e($user->id); ?>"><i
                                                                class="fas fa-trash"></i> حذف المستخدم</a></li>
                                                <?php endif; ?>
                                            </ul>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="4" class="text-center p-4">لا يوجد مستخدمون.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <div class="d-flex justify-content-center mt-3"><?php echo e($users->links()); ?></div>
            </div>
        </div>
    </div>

    
    <div class="modal fade" id="createUserModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form action="<?php echo e(route('admin.users.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header">
                        <h5 class="modal-title">إضافة مستخدم</h5><button type="button" class="btn-close"
                            data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3"><label class="form-label">الاسم الأول</label><input type="text"
                                name="first_name" class="form-control" required></div>
                        <div class="mb-3"><label class="form-label">الاسم الأخير</label><input type="text"
                                name="last_name" class="form-control" required></div>
                        <div class="mb-3"><label class="form-label">البريد الإلكتروني</label><input type="email"
                                name="email" class="form-control" required></div>
                        <div class="mb-3"><label class="form-label">كلمة المرور</label><input type="password"
                                name="password" class="form-control" required></div>
                        <div class="mb-3">
                            <label class="form-label">الدور</label>
                            <select name="role" class="form-select" required>
                                <option value="user" selected>مستخدم عادي</option>
                                <option value="admin">مدير</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer"><button type="button" class="btn btn-secondary"
                            data-bs-dismiss="modal">إغلاق</button><button type="submit"
                            class="btn btn-primary">حفظ</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <!-- نافذة تعديل المستخدم -->
        <div class="modal fade" id="editUserModal<?php echo e($user->id); ?>" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <form action="<?php echo e(route('admin.users.update', $user)); ?>" method="POST">
                        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                        <div class="modal-header">
                            <h5 class="modal-title">تعديل: <?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></h5><button
                                type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div class="mb-3"><label class="form-label">الاسم الأول</label><input type="text"
                                    name="first_name" class="form-control" value="<?php echo e($user->first_name); ?>" required>
                            </div>
                            <div class="mb-3"><label class="form-label">الاسم الأخير</label><input type="text"
                                    name="last_name" class="form-control" value="<?php echo e($user->last_name); ?>" required>
                            </div>
                            <div class="mb-3"><label class="form-label">البريد الإلكتروني</label><input type="email"
                                    name="email" class="form-control" value="<?php echo e($user->email); ?>" required></div>
                            <div class="mb-3"><label class="form-label">كلمة المرور (اتركه فارغاً)</label><input
                                    type="password" name="password" class="form-control"></div>
                            <div class="mb-3">
                                <label class="form-label">الدور</label>
                                <select name="role" class="form-select">
                                    <option value="user" <?php echo e($user->role === 'user' ? 'selected' : ''); ?>>مستخدم عادي
                                    </option>
                                    
                                    <?php if($user->id === 1): ?>
                                        <option value="admin" selected>مدير</option>
                                    <?php else: ?>
                                        <option value="admin" <?php echo e($user->role === 'admin' ? 'selected' : ''); ?>>مدير
                                        </option>
                                    <?php endif; ?>
                                </select>
                            </div>
                        </div>
                        <div class="modal-footer"><button type="button" class="btn btn-secondary"
                                data-bs-dismiss="modal">إغلاق</button><button type="submit"
                                class="btn btn-primary">حفظ</button></div>
                    </form>
                </div>
            </div>
        </div>

        
        <div class="modal fade" id="deactivateUserModal<?php echo e($user->id); ?>" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <form action="<?php echo e(route('admin.users.deactivate', $user)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="modal-header">
                            <h5 class="modal-title">تعطيل: <?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></h5><button
                                type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <p>هل أنت متأكد من تعطيل المستخدم <strong><?php echo e($user->first_name); ?>

                                    <?php echo e($user->last_name); ?></strong>؟</p>
                            <div class="alert alert-warning" role="alert">
                                لن يتمكن المستخدم من تسجيل الدخول أو استخدام خدمات المنصة بعد تعطيل حسابه.
                            </div>
                        </div>
                        <div class="modal-footer"><button type="button" class="btn btn-secondary"
                                data-bs-dismiss="modal">إغلاق</button><button type="submit"
                                class="btn btn-warning">تعطيل</button></div>
                    </form>
                </div>
            </div>
        </div>

        
        <div class="modal fade" id="deleteUserModal<?php echo e($user->id); ?>" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <form action="<?php echo e(route('admin.users.destroy', $user)); ?>" method="POST">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <div class="modal-header">
                            <h5 class="modal-title">تأكيد الحذف</h5><button type="button" class="btn-close"
                                data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <p>هل أنت متأكد من حذف المستخدم <strong><?php echo e($user->first_name); ?>

                                    <?php echo e($user->last_name); ?></strong>؟</p>
                            <div class="alert alert-danger" role="alert">
                                سيتم حذف جميع البيانات المرتبطة بهذا المستخدم بشكل دائم (المعدات، الحجوزات، إلخ).
                            </div>
                        </div>
                        <div class="modal-footer"><button type="button" class="btn btn-secondary"
                                data-bs-dismiss="modal">إلغاء</button><button type="submit"
                                class="btn btn-danger">حذف</button></div>
                    </form>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // تهيئة Tooltips (لا تزال مفيدة لبعض الأزرار)
            var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
            var tooltipList = tooltipTriggerList.map(function(tooltipTriggerEl) {
                return new bootstrap.Tooltip(tooltipTriggerEl)
            });

            // يمكن إزالة أي كود Select2 هنا
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Alhasan\Desktop\final\equipment-rental-project\resources\views/dashboard/users/index.blade.php ENDPATH**/ ?>