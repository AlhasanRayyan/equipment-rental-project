

<?php $__env->startSection('title', $equipment->name); ?>

<?php $__env->startSection('content'); ?>
    <main class="page-main">
        <div class="page-head">
            <div class="page-head__bg" style="background-image: url(<?php echo e(asset('assets/home/img/bg/bg_categories.jpg')); ?>)">
                <div class="page-head__content" data-uk-parallax="y: 0, 100">
                    <div class="uk-container">
                        <div class="page-head__title"><?php echo e($equipment->name); ?></div>
                        <div class="page-head__breadcrumb">
                            <ul class="uk-breadcrumb">
                                <li><a href="<?php echo e(route('home')); ?>">الصفحة الرئيسية</a></li>
                                <li><a href="<?php echo e(route('equipments')); ?>">المعدات</a></li>
                                <li><span><?php echo e($equipment->name); ?></span></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="page-content">
            <div class="uk-section-large uk-container">
                <div class="uk-grid" data-uk-grid>
                    <div class="uk-width-2-3@m">
                        <div class="equipment-detail">

                            
                            <div class="equipment-detail__gallery">
                                <?php if($equipment->images->count()): ?>
                                    <div data-uk-slideshow="min-height: 300; max-height: 430">
                                        <div class="uk-position-relative">
                                            <ul class="uk-slideshow-items uk-child-width-1-1"
                                                data-uk-lightbox="animation: scale">
                                                <?php $__currentLoopData = $equipment->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li>
                                                        <a href="<?php echo e(asset('storage/' . $image->image_url)); ?>">
                                                            <img class="uk-width-1-1"
                                                                src="<?php echo e(asset('storage/' . $image->image_url)); ?>"
                                                                alt="<?php echo e($equipment->name); ?>" data-uk-cover>
                                                        </a>
                                                    </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                            <a class="uk-position-center-left uk-position-small uk-hidden-hover"
                                                href="#" data-uk-slidenav-previous
                                                data-uk-slideshow-item="previous"></a>
                                            <a class="uk-position-center-right uk-position-small uk-hidden-hover"
                                                href="#" data-uk-slidenav-next data-uk-slideshow-item="next"></a>
                                        </div>

                                        <div class="uk-margin-top" data-uk-slider>
                                            <ul
                                                class="uk-thumbnav uk-slider-items uk-grid uk-grid-small uk-child-width-1-4@m">
                                                <?php $__currentLoopData = $equipment->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li data-uk-slideshow-item="<?php echo e($i); ?>">
                                                        <a href="#"><img
                                                                src="<?php echo e(asset('storage/' . $image->image_url)); ?>"
                                                                alt="<?php echo e($equipment->name); ?>"></a>
                                                    </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>
                                    </div>
                                <?php else: ?>
                                    <p>لا توجد صور متاحة لهذه المعدة.</p>
                                <?php endif; ?>
                            </div>

                            <div class="equipment-detail__title"><?php echo e($equipment->name); ?></div>
                            <div class="equipment-detail__location">
                                <span data-uk-icon="location"></span> <?php echo e($equipment->location_address); ?>

                            </div>

                            <div class="equipment-detail__desc">
                                <div class="section-title">
                                    <div class="uk-h2">الوصف</div>
                                </div>
                                <p><?php echo e($equipment->description ?? 'لا يوجد وصف متاح.'); ?></p>
                            </div>

                            <div class="equipment-detail__specification">
                                <div class="section-title">
                                    <div class="uk-h2">معلومات</div>
                                </div>
                                <table class="uk-table uk-table-striped">
                                    
                                    <div class="uk-card uk-card-default uk-card-body uk-margin-medium-top uk-text-center">
                                        <h4 class="uk-heading-line"><span>مشاركة المعدة</span></h4>

                                        
                                        <div class="uk-margin">
                                            <p class="uk-text-small uk-text-muted">يمكنك مشاركة هذه المعدة عبر الرابط
                                                التالي:</p>
                                            <div class="uk-inline uk-width-expand">
                                                <input class="uk-input uk-text-center" type="text"
                                                    value="<?php echo e(route('equipments.show', $equipment->id)); ?>" readonly
                                                    id="equipmentLink">
                                                <button class="uk-button uk-button-primary uk-margin-small-top"
                                                    onclick="copyEquipmentLink()">نسخ الرابط</button>
                                            </div>
                                        </div>

                                        
                                        <div class="uk-margin">
                                            <p class="uk-text-small uk-text-muted">أو امسح رمز QR لفتح الصفحة مباشرة:</p>
                                            <div class="uk-flex uk-flex-center uk-margin-small-bottom">
                                                <?php echo QrCode::size(200)->generate(route('equipments.show', $equipment->id)); ?>

                                            </div>

                                            
                                            <a class="uk-button uk-button-default uk-margin-small-top"
                                                href="data:image/png;base64,<?php echo e(base64_encode(QrCode::format('png')->size(300)->generate(route('equipments.show', $equipment->id)))); ?>"
                                                download="equipment-<?php echo e($equipment->id); ?>.png">
                                                تحميل رمز QR
                                            </a>
                                        </div>
                                        
                                        <div class="uk-margin">
                                            <p class="uk-text-small uk-text-muted">شارك عبر:</p>

                                            <div class="uk-flex uk-flex-center uk-grid-small" data-uk-grid>
                                                <?php
                                                    $shareUrl = urlencode(route('equipments.show', $equipment->id));
                                                    $shareText = urlencode(
                                                        'شاهد هذه المعدة على منصة تأجير المعدات: ' . $equipment->name,
                                                    );
                                                ?>

                                                <a href="https://wa.me/?text=<?php echo e($shareText); ?>%20<?php echo e($shareUrl); ?>"
                                                    class="share-btn whatsapp" target="_blank" title="واتساب">
                                                    <i class="fab fa-whatsapp"></i>
                                                </a>

                                                <a href="https://t.me/share/url?url=<?php echo e($shareUrl); ?>&text=<?php echo e($shareText); ?>"
                                                    class="share-btn telegram" target="_blank" title="تليجرام">
                                                    <i class="fab fa-telegram-plane"></i>
                                                </a>

                                                <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e($shareUrl); ?>"
                                                    class="share-btn facebook" target="_blank" title="فيسبوك">
                                                    <i class="fab fa-facebook-f"></i>
                                                </a>

                                                <a href="https://twitter.com/intent/tweet?url=<?php echo e($shareUrl); ?>&text=<?php echo e($shareText); ?>"
                                                    class="share-btn twitter" target="_blank" title="تويتر">
                                                    <i class="fab fa-x-twitter"></i>
                                                </a>
                                            </div>
                                        </div>

                                    </div>

                                    <tr>
                                        <td>سعر الإيجار اليومي:</td>
                                        <td><?php echo e($equipment->daily_rate ?? '-'); ?> $</td>
                                    </tr>
                                    <tr>
                                        <td>سعر الإيجار الأسبوعي:</td>
                                        <td><?php echo e($equipment->weekly_rate ?? '-'); ?> $</td>
                                    </tr>
                                    <tr>
                                        <td>سعر الإيجار الشهري:</td>
                                        <td><?php echo e($equipment->monthly_rate ?? '-'); ?> $</td>
                                    </tr>
                                    <tr>
                                        <td>قيمة الإيداع:</td>
                                        <td><?php echo e($equipment->deposit_amount ?? '-'); ?> $</td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>

                    <div class="uk-width-1-3@m">
                        <div class="equipment-sidebar">

                            
                            <div
                                class="equipment-user uk-card uk-card-default uk-card-body uk-text-center uk-margin-medium-bottom">
                                <img class="uk-border-circle"
                                    src="<?php echo e($equipment->owner->avatar_url ?? asset('assets/home/img/default-user.png')); ?>"
                                    width="120" height="120" alt="">
                                <h4 class="uk-margin-small-top"><?php echo e($equipment->owner->name); ?></h4>
                                <p><?php echo e($equipment->owner->description ?? 'مالك المعدات'); ?></p>
                            </div>

                            
                            <form action="" method="POST"
                                class="uk-card uk-card-default uk-card-body equipment-order">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="equipment_id" value="<?php echo e($equipment->id); ?>">

                                <div class="equipment-order__price">
                                    <span>مدة الإيجار<small>اختر المدة</small></span>
                                </div>

                                <div class="equipment-order__form">
                                    <div class="uk-margin">
                                        <div class="uk-inline uk-width-1-1">
                                            <select class="uk-select uk-form-large" name="rental_type" required>
                                                <option value="">مدة الإيجار</option>
                                                <option value="daily">يومي</option>
                                                <option value="weekly">أسبوعي</option>
                                                <option value="monthly">شهري</option>
                                            </select>
                                            <span class="uk-form-icon">
                                                <img class="timer"
                                                    src="<?php echo e(asset('assets/home/img/icons/ico-timer.svg')); ?>"
                                                    alt="timer" data-uk-svg>
                                            </span>
                                        </div>
                                    </div>

                                    <div class="uk-margin">
                                        <input class="uk-input" type="date" name="start_date" required
                                            placeholder="تاريخ البدء">
                                    </div>

                                    <div class="uk-margin">
                                        <input class="uk-input" type="date" name="end_date" required
                                            placeholder="تاريخ الإنتهاء">
                                    </div>

                                    <div class="uk-margin">
                                        <input class="uk-input" type="text" name="delivery_address"
                                            placeholder="أدخل عنوانك">
                                    </div>

                                    <div class="uk-margin">
                                        <div class="equipment-order__value">
                                            <span data-uk-icon="check"></span>
                                            <span id="rentalDays">المدة بالأيام : -</span>
                                        </div>
                                    </div>
                                </div>

                                <div class="equipment-order-total">
                                    <ul>
                                        <li><span>إجمالي الإيجار</span><span id="rentalTotal">-</span></li>
                                        <li><span>قيمة الإيداع</span><span><?php echo e($equipment->deposit_amount ?? 0); ?> $</span>
                                        </li>
                                        <li><span>الإجمالي</span><span id="rentalGrand">-</span></li>
                                    </ul>

                                    <button class="uk-button uk-button-large uk-width-1-1" type="submit">
                                        <span>استئجار الآن</span>
                                        <img class="makos" src="<?php echo e(asset('assets/home/img/icons/arrow.svg')); ?>"
                                            alt="arrow" data-uk-svg>
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </main>
    <?php $__env->startPush('scripts'); ?>
        <script>
            function copyEquipmentLink() {
                const input = document.getElementById('equipmentLink');
                input.select();
                input.setSelectionRange(0, 99999);
                navigator.clipboard.writeText(input.value);
                UIkit.notification({
                    message: '✅ تم نسخ الرابط بنجاح!',
                    status: 'success'
                });
            }
        </script>

        <script>
            document.addEventListener('DOMContentLoaded', function() {
                const startInput = document.querySelector('[name="start_date"]');
                const endInput = document.querySelector('[name="end_date"]');
                const typeSelect = document.querySelector('[name="rental_type"]');
                const rentalDays = document.getElementById('rentalDays');
                const rentalTotal = document.getElementById('rentalTotal');
                const rentalGrand = document.getElementById('rentalGrand');

                function updatePrices() {
                    if (!startInput.value || !endInput.value || !typeSelect.value) return;

                    const start = new Date(startInput.value);
                    const end = new Date(endInput.value);
                    const diff = (end - start) / (1000 * 60 * 60 * 24);
                    if (diff < 1) return;

                    rentalDays.textContent = `المدة بالأيام: ${diff} يوم`;

                    let rate = 0;
                    switch (typeSelect.value) {
                        case 'daily':
                            rate = <?php echo e($equipment->daily_rate ?? 0); ?>;
                            break;
                        case 'weekly':
                            rate = <?php echo e($equipment->weekly_rate ?? 0); ?>;
                            break;
                        case 'monthly':
                            rate = <?php echo e($equipment->monthly_rate ?? 0); ?>;
                            break;
                    }

                    const total = rate * (typeSelect.value === 'daily' ? diff : typeSelect.value === 'weekly' ? diff /
                        7 : diff / 30);
                    const deposit = <?php echo e($equipment->deposit_amount ?? 0); ?>;
                    rentalTotal.textContent = `$${total.toFixed(2)}`;
                    rentalGrand.textContent = `$${(total + deposit).toFixed(2)}`;
                }

                startInput.addEventListener('change', updatePrices);
                endInput.addEventListener('change', updatePrices);
                typeSelect.addEventListener('change', updatePrices);
            });
        </script>
    <?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Alhasan\Desktop\final\equipment-rental-project\resources\views/frontend/equipments/show.blade.php ENDPATH**/ ?>