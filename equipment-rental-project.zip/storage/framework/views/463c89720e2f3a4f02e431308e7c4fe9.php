<?php $__env->startSection('styles'); ?>
    <style>
        .category-image {
            width: 50px;
            height: 50px;
            object-fit: cover;
            border-radius: 0.5rem;
        }

        .action-dropdown .dropdown-menu {
            min-width: 200px;
            border-radius: 0.5rem;
            box-shadow: 0 .5rem 1rem rgba(0, 0, 0, .15);
        }

        .action-dropdown .dropdown-item {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 0.5rem 1rem;
        }

        .action-dropdown .dropdown-item i {
            width: 18px;
            text-align: center;
            opacity: 0.7;
        }

        /* لتنسيق الفئات الفرعية في الجدول */
        .subcategory-indent {
            padding-right: 20px;
            /* مسافة بادئة لتمييز الفئات الفرعية */
            position: relative;
        }

        .subcategory-indent::before {
            content: "—";
            /* خط صغير لتمييزها */
            position: absolute;
            right: 5px;
            top: 50%;
            transform: translateY(-50%);
            color: #6c757d;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="h3 mb-0 text-gray-800">إدارة فئات المعدات</h1>
            <div>
                <a href="<?php echo e(route('admin.categories.stats')); ?>" class="btn btn-outline-primary me-2">
                    <i class="fas fa-chart-bar me-1"></i> إحصائيات الفئات
                </a>
                <a href="<?php echo e(route('admin.categories.trash')); ?>" class="btn btn-outline-danger  me-2">
                    <i class="fas fa-trash-alt"></i> سلة المحذوفات
                </a>
                <button class="btn btn-primary shadow-sm" data-bs-toggle="modal" data-bs-target="#createCategoryModal">
                    <i class="fas fa-plus fa-sm me-2"></i>إضافة فئة جديدة
                </button>
            </div>
        </div>


        <?php echo $__env->make('partials.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="card shadow">
            <div class="card-header py-3">
                <div class="d-flex flex-column flex-md-row justify-content-between align-items-center">
                    <h6 class="m-0 fw-bold text-primary mb-2 mb-md-0">
                        <i class="fas fa-list me-2"></i>قائمة الفئات (<?php echo e($categories->total()); ?>)
                    </h6>
                    <form action="<?php echo e(route('admin.categories.index')); ?>" method="GET" class="d-flex"
                        style="max-width: 400px; width: 100%;">
                        <input type="text" name="query" class="form-control" placeholder="ابحث بالاسم أو الوصف..."
                            value="<?php echo e($query ?? ''); ?>">
                        <button type="submit" class="btn btn-primary ms-2"><i class="fas fa-search"></i></button>
                        <?php if($query ?? ''): ?>
                            <a href="<?php echo e(route('admin.categories.index')); ?>" class="btn btn-secondary ms-2"
                                title="إلغاء البحث"><i class="fas fa-times"></i></a>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>الفئة</th>
                                <th>الفئة الرئيسية</th> 
                                <th>الوصف</th>
                                <th class="text-center">المعدات المرتبطة</th>
                                <th class="text-center">الحالة</th>
                                <th class="text-center">الإجراءات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="<?php echo e($category->parent_id ? 'subcategory-indent' : ''); ?>">
                                        
                                        <div class="d-flex align-items-center">
                                            <img src="<?php echo e($category->image_url ? asset('storage/' . $category->image_url) : asset('assets/img/default-category.png')); ?>"
                                                alt="صورة الفئة" class="category-image me-3">
                                            <div class="fw-bold"><?php echo e(Str::limit($category->category_name, 30)); ?></div>
                                        </div>
                                    </td>
                                    <td>
                                        <?php if($category->parent): ?>
                                            
                                            <span class="badge bg-secondary"><?php echo e($category->parent->category_name); ?></span>
                                        <?php else: ?>
                                            <span class="text-muted small">فئة رئيسية</span>
                                        <?php endif; ?>
                                    </td>
                                    
                                    <td><?php echo e(Str::words($category->description, 5, '...') ?? 'لا يوجد وصف.'); ?></td>
                                    <td class="text-center">
                                        <a href="<?php echo e(route('admin.categories.showEquipment', $category)); ?>"
                                            class="btn btn-sm btn-info"><?php echo e($category->equipment_count); ?> معدة</a>
                                    </td>
                                    <td class="text-center">
                                        <?php if($category->is_active): ?>
                                            <span class="badge bg-success">نشط</span>
                                        <?php else: ?>
                                            <span class="badge bg-warning text-dark">غير نشط</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center">
                                        <div class="dropdown action-dropdown">
                                            <button class="btn btn-light btn-sm dropdown-toggle" type="button"
                                                data-bs-toggle="dropdown">إجراءات</button>
                                            <ul class="dropdown-menu dropdown-menu-end">
                                                <li><a class="dropdown-item" href="#" data-bs-toggle="modal"
                                                        data-bs-target="#editCategoryModal<?php echo e($category->id); ?>"><i
                                                            class="fas fa-edit text-warning"></i> تعديل الفئة</a></li>
                                                <li>
                                                    <hr class="dropdown-divider">
                                                </li>
                                                <li><a class="dropdown-item text-danger" href="#"
                                                        data-bs-toggle="modal"
                                                        data-bs-target="#deleteCategoryModal<?php echo e($category->id); ?>"><i
                                                            class="fas fa-trash"></i> حذف الفئة</a></li>
                                            </ul>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6" class="text-center p-4">لا توجد فئات معدات.</td>
                                </tr> 
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <div class="d-flex justify-content-center mt-3"><?php echo e($categories->links()); ?></div>
            </div>
        </div>
    </div>

    
    <div class="modal fade" id="createCategoryModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form action="<?php echo e(route('admin.categories.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header">
                        <h5 class="modal-title">إضافة فئة جديدة</h5><button type="button" class="btn-close"
                            data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">اسم الفئة</label>
                            <input type="text" name="category_name" class="form-control"
                                value="<?php echo e(old('category_name')); ?>" required>
                            <?php $__errorArgs = ['category_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger small"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">الفئة الرئيسية (اختياري)</label>
                            <select name="parent_id" class="form-select"> 
                                <option value="">-- فئة رئيسية (لا يوجد والد) --</option>
                                <?php $__currentLoopData = $parentCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parentCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($parentCategory->id); ?>"
                                        <?php echo e(old('parent_id') == $parentCategory->id ? 'selected' : ''); ?>>
                                        <?php echo e($parentCategory->category_name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['parent_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger small"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">الوصف</label>
                            <textarea name="description" class="form-control" rows="3"><?php echo e(old('description')); ?></textarea>
                            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger small"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">صورة الفئة</label>
                            <input type="file" name="image" class="form-control" accept="image/*">
                            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger small"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 form-check">
                            <input type="checkbox" name="is_active" id="createIsActive" class="form-check-input"
                                value="1" <?php echo e(old('is_active', true) ? 'checked' : ''); ?>>
                            <label class="form-check-label" for="createIsActive">نشط</label>
                            <?php $__errorArgs = ['is_active'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger small"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="modal-footer"><button type="button" class="btn btn-secondary"
                            data-bs-dismiss="modal">إغلاق</button><button type="submit"
                            class="btn btn-primary">حفظ</button></div>
                </form>
            </div>
        </div>
    </div>

    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <div class="modal fade" id="editCategoryModal<?php echo e($category->id); ?>" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <form action="<?php echo e(route('admin.categories.update', $category)); ?>" method="POST"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                        <div class="modal-header">
                            <h5 class="modal-title">تعديل: <?php echo e($category->category_name); ?></h5><button type="button"
                                class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div class="mb-3">
                                <label class="form-label">اسم الفئة</label>
                                <input type="text" name="category_name" class="form-control"
                                    value="<?php echo e(old('category_name', $category->category_name)); ?>" required>
                                <?php $__errorArgs = ['category_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger small"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">الفئة الرئيسية (اختياري)</label>
                                <select name="parent_id" class="form-select"> 
                                    <option value="">-- فئة رئيسية (لا يوجد والد) --</option>
                                    <?php $__currentLoopData = $parentCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parentCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        
                                        <?php if($parentCategory->id === $category->id || $category->children->contains($parentCategory->id)): ?>
                                            <?php continue; ?>
                                        <?php endif; ?>
                                        <option value="<?php echo e($parentCategory->id); ?>"
                                            <?php echo e(old('parent_id', $category->parent_id) == $parentCategory->id ? 'selected' : ''); ?>>
                                            <?php echo e($parentCategory->category_name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['parent_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger small"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">الوصف</label>
                                <textarea name="description" class="form-control" rows="3"><?php echo e(old('description', $category->description)); ?></textarea>
                                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger small"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">صورة الفئة</label>
                                <?php if($category->image_url): ?>
                                    <div class="mb-2">
                                        <img src="<?php echo e(asset('storage/' . $category->image_url)); ?>" alt="صورة حالية"
                                            class="category-image" style="width: 80px; height: 80px;">
                                        <small class="text-muted d-block">الصورة الحالية (يمكنك رفع صورة جديدة
                                            لاستبدالها)</small>
                                    </div>
                                <?php endif; ?>
                                <input type="file" name="image" class="form-control" accept="image/*">
                                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger small"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3 form-check">
                                <input type="checkbox" name="is_active" id="editIsActive<?php echo e($category->id); ?>"
                                    class="form-check-input" value="1"
                                    <?php echo e(old('is_active', $category->is_active) ? 'checked' : ''); ?>>
                                <label class="form-check-label" for="editIsActive<?php echo e($category->id); ?>">نشط</label>
                                <?php $__errorArgs = ['is_active'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger small"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="modal-footer"><button type="button" class="btn btn-secondary"
                                data-bs-dismiss="modal">إغلاق</button><button type="submit" class="btn btn-primary">حفظ
                                التغييرات</button></div>
                    </form>
                </div>
            </div>
        </div>

        
        <div class="modal fade" id="deleteCategoryModal<?php echo e($category->id); ?>" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <form action="<?php echo e(route('admin.categories.destroy', $category)); ?>" method="POST">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <div class="modal-header">
                            <h5 class="modal-title">تأكيد الحذف</h5><button type="button" class="btn-close"
                                data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <p>هل أنت متأكد من حذف الفئة <strong><?php echo e($category->category_name); ?></strong>؟</p>
                            <?php if($category->equipment_count > 0): ?>
                                <div class="alert alert-danger" role="alert">
                                    هذه الفئة مرتبطة بـ <strong><?php echo e($category->equipment_count); ?></strong> معدة. لا يمكن
                                    حذفها حتى يتم نقل هذه المعدات إلى فئة أخرى أو حذفها.
                                </div>
                            <?php elseif($category->children->count() > 0): ?>
                                
                                <div class="alert alert-danger" role="alert">
                                    هذه الفئة تحتوي على <strong><?php echo e($category->children->count()); ?></strong> فئات فرعية. لا
                                    يمكن حذفها حتى يتم حذف الفئات الفرعية أولاً.
                                </div>
                            <?php else: ?>
                                <div class="alert alert-warning" role="alert">
                                    سيتم حذف هذه الفئة بشكل دائم.
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                            <button type="submit" class="btn btn-danger"
                                <?php echo e($category->equipment_count > 0 || $category->children->count() > 0 ? 'disabled' : ''); ?>>حذف</button>
                            
                        </div>
                    </form>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // تهيئة Tooltips
            var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
            var tooltipList = tooltipTriggerList.map(function(tooltipTriggerEl) {
                return new bootstrap.Tooltip(tooltipTriggerEl)
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Alhasan\Desktop\final\equipment-rental-project\resources\views/dashboard/categories/index.blade.php ENDPATH**/ ?>