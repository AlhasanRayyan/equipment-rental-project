<?php $__env->startSection('title', 'المفضلة'); ?> 

<?php $__env->startSection('content'); ?>
    <div class="page-head">
        <div class="page-head__bg" style="background-image: url(<?php echo e(asset('assets/home/img/bg/bg_blog.jpg')); ?>)">
            <div class="page-head__content" data-uk-parallax="y: 0, 100">
                <div class="uk-container">
                    <div class="header-icons"><span></span><span></span><span></span></div>
                    <div class="page-head__title"> المفضلة </div>
                </div>
            </div>
        </div>
    </div>
    <!-- start search par  -->
    <div class="section-find section-find1">
        <div class="uk-container">
            <div class="find-box">
                <div class="find-box__title"> <span>ابحث في المفضلة</span></div>
                <div class="find-box__form">
                    <form action="<?php echo e(route('favorites.index')); ?>" method="GET">
                        <div class="uk-grid uk-grid-medium uk-flex-middle uk-child-width-1-3@m uk-child-width-1-2@s" data-uk-grid>
                            <div>
                                <div class="uk-inline uk-width-1-1">
                                    <select class="uk-select uk-form-large" name="category">
                                        <option value="">إختر الصنف</option>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($category->id); ?>" <?php if(request('category') == $category->id): ?> selected <?php endif; ?>><?php echo e($category->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <span class="uk-form-icon"><img src="<?php echo e(asset('assets/img/icons/truck.svg')); ?>" alt="truck" data-uk-svg></span>
                                </div>
                            </div>
                            <div>
                                <div class="uk-inline uk-width-1-1">
                                    <input class="uk-input uk-form-large uk-width-1-1" type="text" name="equipment_name" placeholder="اسم المعدة" value="<?php echo e(request('equipment_name')); ?>">
                                    <span class="uk-form-icon"><img src="<?php echo e(asset('assets/img/icons/derrick.svg')); ?>" alt="derrick" data-uk-svg></span>
                                </div>
                            </div>
                            <div>
                                <input class="main-input uk-input uk-form-large uk-width-1-1" type="submit" value="ابحث هنا">
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- end search par    -->
    <div class="page-content">
        <div class="uk-section-large uk-container">
            <?php if(session('success')): ?>
                <div class="uk-alert-success" data-uk-alert>
                    <a class="uk-alert-close" data-uk-close></a>
                    <p><?php echo e(session('success')); ?></p>
                </div>
            <?php endif; ?>
            <?php if(session('error')): ?>
                <div class="uk-alert-danger" data-uk-alert>
                    <a class="uk-alert-close" data-uk-close></a>
                    <p><?php echo e(session('error')); ?></p>
                </div>
            <?php endif; ?>

            <?php if($favorites->isEmpty()): ?>
                <p class="uk-text-center uk-text-large uk-margin-large-top">لا توجد معدات في المفضلة بعد.</p>
            <?php else: ?>
                <div class="uk-grid uk-grid-medium uk-child-width-1-3@m uk-child-width-1-2@s" data-uk-grid>
                    <?php $__currentLoopData = $favorites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userFavorite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $equipment = $userFavorite->equipment;
                            // في حال تم حذف المعدة الأساسية، يمكن تخطيها
                            if (!$equipment) continue;
                        ?>
                        <div>
                            <div class="blog-item">
                                <div class="blog-item__media">
                                    <a href="<?php echo e(route('equipments.show', $equipment->id)); ?>">
                                        
                                        <img src="<?php echo e($equipment->images->first() ? asset('storage/' . $equipment->images->first()->image_path) : asset('assets/img/blog-placeholder.jpg')); ?>"
                                             alt="<?php echo e($equipment->name); ?>">
                                    </a>
                                    <div class="blog-item__Favorites">
                                        
                                        <form action="<?php echo e(route('favorites.destroy', $userFavorite->id)); ?>" method="POST" class="remove-favorite-form">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            
<input type="checkbox" checked="checked" id="favorite_<?php echo e($userFavorite->id); ?>" name="favorite-checkbox" value="favorite-button" style="display: none;">                                            <label for="favorite_<?php echo e($userFavorite->id); ?>" class="containerrr">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none"
                                                    stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                                    class="feather feather-heart">
                                                    <path
                                                      d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z">
                                                    </path>
                                                </svg>
                                            </label>
                                        </form>
                                    </div>
                                </div>
                                <div class="blog-item__body">
                                    <div class="blog-item__info">
                                        <div class="blog-item__date"><?php echo e($userFavorite->created_at->format('d M Y')); ?></div>
                                        <div class="blog-item__author"> بواسطة<a href="#"><?php echo e($equipment->owner->name ?? 'غير معروف'); ?> </a></div>
                                    </div>
                                    <div class="blog-item__title"><?php echo e($equipment->name); ?></div>
                                    <div class="blog-item__intro"><?php echo e(Str::limit($equipment->description, 100)); ?></div>
                                    <!-- start stars  -->
                                    <div class="rating">
                                        <?php $avgRating = round($equipment->average_rating ?? 0); ?>
                                        <?php for($i = 5; $i >= 1; $i--): ?>
                                            
                                            <input value="<?php echo e($i); ?>" name="rate_<?php echo e($equipment->id); ?>" id="star<?php echo e($i); ?>_<?php echo e($equipment->id); ?>" type="radio" <?php if($avgRating == $i): ?> checked="" <?php endif; ?>>
                                            <label title="text" for="star<?php echo e($i); ?>_<?php echo e($equipment->id); ?>"></label>
                                        <?php endfor; ?>
                                    </div>
                                    <!-- end stars  -->
                                </div>
                                <div class="blog-item__bottom">
                                    <a class="link-more" href="<?php echo e(route('equipments.show', $equipment->id)); ?>">
                                        <span>إقرأ أكثر </span>
                                        <img class="makos" src="<?php echo e(asset('assets/img/icons/arrow.svg')); ?>" alt="arrow" data-uk-svg>
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
           
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?> 
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            document.querySelectorAll('.blog-item__Favorites input[type="checkbox"]').forEach(function(checkbox) {
                checkbox.addEventListener('change', function() {
                    if (!this.checked) { // إذا تم إلغاء تحديد خانة الاختيار
                        const form = this.closest('form');
                        if (form) {
                            form.submit(); // إرسال النموذج لحذف المفضلة
                        }
                    }
                });
            });
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Alhasan\Desktop\final\equipment-rental-project\resources\views/frontend/favorites.blade.php ENDPATH**/ ?>