<?php $__env->startSection('content'); ?>
    <div class="container-fluid">

        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="h3 mb-0 text-gray-800">تفاصيل الحجز #<?php echo e($booking->id); ?></h1>

            <div>
                <a href="<?php echo e(route('admin.bookings.index')); ?>" class="btn btn-secondary btn-sm">
                    <i class="fas fa-arrow-right ms-1"></i> رجوع لقائمة الحجوزات
                </a>
            </div>
        </div>

        
        <div class="row mb-4">
            <div class="col-lg-4 mb-3">
                <div class="card shadow h-100">
                    <div class="card-header">
                        <strong>الحالة العامة</strong>
                    </div>
                    <div class="card-body">
                        <p>
                            <strong>حالة الحجز:</strong>
                            <?php
                                $status = $booking->booking_status;
                            ?>

                            <?php switch($status):
                                case ('pending'): ?>
                                    <span class="badge bg-warning text-dark">قيد الانتظار</span>
                                <?php break; ?>

                                <?php case ('confirmed'): ?>
                                    <span class="badge bg-primary">مؤكد</span>
                                <?php break; ?>

                                <?php case ('active'): ?>
                                    <span class="badge bg-info text-dark">نشط</span>
                                <?php break; ?>

                                <?php case ('completed'): ?>
                                    <span class="badge bg-success">مكتمل</span>
                                <?php break; ?>

                                <?php case ('cancelled'): ?>
                                    <span class="badge bg-danger">ملغي</span>
                                <?php break; ?>

                                <?php default: ?>
                                    <span class="badge bg-secondary"><?php echo e($status); ?></span>
                            <?php endswitch; ?>
                        </p>

                        <p>
                            <strong>حالة الدفع:</strong>
                            <?php
                                $payStatus = $booking->payment_status;
                            ?>

                            <?php switch($payStatus):
                                case ('pending'): ?>
                                    <span class="badge bg-warning text-dark">بانتظار الدفع</span>
                                <?php break; ?>

                                <?php case ('paid'): ?>
                                    <span class="badge bg-success">مدفوع</span>
                                <?php break; ?>

                                <?php case ('refunded'): ?>
                                    <span class="badge bg-info text-dark">مسترد</span>
                                <?php break; ?>

                                <?php case ('failed'): ?>
                                    <span class="badge bg-danger">فشل الدفع</span>
                                <?php break; ?>

                                <?php default: ?>
                                    <span class="badge bg-secondary"><?php echo e($payStatus); ?></span>
                            <?php endswitch; ?>
                        </p>

                        <p>
                            <strong>تاريخ الإنشاء:</strong>
                            <?php echo e($booking->created_at?->format('Y-m-d H:i') ?? '-'); ?>

                        </p>

                        <?php if($booking->confirmed_at): ?>
                            <p><strong>تاريخ التأكيد:</strong> <?php echo e($booking->confirmed_at->format('Y-m-d H:i')); ?></p>
                        <?php endif; ?>

                        <?php if($booking->cancelled_at): ?>
                            <p><strong>تاريخ الإلغاء:</strong> <?php echo e($booking->cancelled_at->format('Y-m-d H:i')); ?></p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            
            <div class="col-lg-4 mb-3">
                <div class="card shadow h-100">
                    <div class="card-header">
                        <strong>تفاصيل الفترة والتكلفة</strong>
                    </div>
                    <div class="card-body">
                        <p>
                            <strong>تاريخ البدء:</strong>
                            <?php echo e($booking->start_date ?? '-'); ?>

                        </p>
                        <p>
                            <strong>تاريخ الانتهاء:</strong>
                            <?php echo e($booking->end_date ?? '-'); ?>

                        </p>
                        <p>
                            <strong>مدة الإيجار (أيام):</strong>
                            <?php echo e($booking->rental_duration_days); ?>

                        </p>
                        <p>
                            <strong>نوع التسعير:</strong>
                            <?php switch($booking->rental_rate_type):
                                case ('daily'): ?>
                                    يومي
                                <?php break; ?>

                                <?php case ('weekly'): ?>
                                    أسبوعي
                                <?php break; ?>

                                <?php case ('monthly'): ?>
                                    شهري
                                <?php break; ?>

                                <?php default: ?>
                                    <?php echo e($booking->rental_rate_type); ?>

                            <?php endswitch; ?>
                        </p>
                        <p>
                            <strong>إجمالي التكلفة:</strong>
                            $<?php echo e(number_format($booking->total_cost, 2)); ?>

                        </p>
                        <p>
                            <strong>العربون المدفوع:</strong>
                            $<?php echo e(number_format($booking->deposit_amount_paid, 2)); ?>

                        </p>
                    </div>
                </div>
            </div>

            
            <div class="col-lg-4 mb-3">
                <div class="card shadow h-100">
                    <div class="card-header">
                        <strong>تفاصيل إضافية</strong>
                    </div>
                    <div class="card-body">
                        <p>
                            <strong>موقع الاستلام:</strong>
                            <?php echo e($booking->pickup_location ?? '-'); ?>

                        </p>
                        <p>
                            <strong>موقع الإرجاع:</strong>
                            <?php echo e($booking->return_location ?? '-'); ?>

                        </p>

                        <?php if($booking->contract_url): ?>
                            <p>
                                <strong>عقد الإيجار:</strong>
                                <a href="<?php echo e($booking->contract_url); ?>" target="_blank">
                                    عرض العقد <i class="fas fa-external-link-alt ms-1"></i>
                                </a>
                            </p>
                        <?php endif; ?>

                        <?php if($booking->special_requirements): ?>
                            <p class="mb-0">
                                <strong>متطلبات خاصة:</strong><br>
                                <span style="white-space: pre-line;">
                                    <?php echo e($booking->special_requirements); ?>

                                </span>
                            </p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        
        <div class="row mb-4">
            
            <div class="col-lg-4 mb-3">
                <div class="card shadow h-100">
                    <div class="card-header">
                        <strong>المستأجر (Renter)</strong>
                    </div>
                    <div class="card-body">
                        <?php $renter = $booking->renter; ?>
                        <?php if($renter): ?>
                            <p><strong>الاسم:</strong> <?php echo e($renter->first_name); ?> <?php echo e($renter->last_name); ?></p>
                            <p><strong>البريد:</strong> <?php echo e($renter->email); ?></p>
                            <p><strong>الهاتف:</strong> <?php echo e($renter->phone ?? '-'); ?></p>
                            <a href="<?php echo e(route('admin.users.show', $renter)); ?>" class="btn btn-sm btn-outline-primary">
                                عرض ملف المستخدم
                            </a>
                        <?php else: ?>
                            <p class="text-muted mb-0">تم حذف المستأجر أو غير متوفر.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            
            <div class="col-lg-4 mb-3">
                <div class="card shadow h-100">
                    <div class="card-header">
                        <strong>مالك المعدّة (Owner)</strong>
                    </div>
                    <div class="card-body">
                        <?php $owner = $booking->owner; ?>
                        <?php if($owner): ?>
                            <p><strong>الاسم:</strong> <?php echo e($owner->first_name); ?> <?php echo e($owner->last_name); ?></p>
                            <p><strong>البريد:</strong> <?php echo e($owner->email); ?></p>
                            <p><strong>الهاتف:</strong> <?php echo e($owner->phone ?? '-'); ?></p>
                            <a href="<?php echo e(route('admin.users.show', $owner)); ?>" class="btn btn-sm btn-outline-primary">
                                عرض ملف المالك
                            </a>
                        <?php else: ?>
                            <p class="text-muted mb-0">تم حذف المالك أو غير متوفر.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            
            <div class="col-lg-4 mb-3">
                <div class="card shadow h-100">
                    <div class="card-header">
                        <strong>المعدة المحجوزة</strong>
                    </div>
                    <div class="card-body">
                        <?php $equipment = $booking->equipment; ?>
                        <?php if($equipment): ?>
                            <p><strong>الاسم:</strong> <?php echo e($equipment->name ?? '-'); ?></p>
                            <p><strong>الفئة:</strong> <?php echo e(optional($equipment->category)->category_name ?? '-'); ?></p>
                            <?php if($equipment->images && $equipment->images->first()): ?>
                                <img src="<?php echo e($equipment->images->first()->image_url); ?>" alt="صورة المعدة"
                                    class="img-thumbnail mb-2" style="max-width: 120px;">
                            <?php endif; ?>
                            <a href="<?php echo e(route('admin.equipment.index', ['query' => $equipment->name])); ?>"
                                class="btn btn-sm btn-outline-secondary">
                                فتح في صفحة المعدات
                            </a>
                        <?php else: ?>
                            <p class="text-muted mb-0">تم حذف المعدة أو غير متوفرة.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Alhasan\Desktop\final\equipment-rental-project\resources\views/dashboard/bookings/show.blade.php ENDPATH**/ ?>