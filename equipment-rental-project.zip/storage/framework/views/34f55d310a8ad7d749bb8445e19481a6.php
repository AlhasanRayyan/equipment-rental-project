<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="h3 mb-0 text-gray-800">إدارة الحجوزات</h1>
            <a href="<?php echo e(route('admin.bookings.trash')); ?>" class="btn btn-outline-danger">
                سلة المحذوفات
            </a>
        </div>

        <div class="card shadow">
            
            <div class="card-header py-3">
                <form action="<?php echo e(route('admin.bookings.index')); ?>" method="GET" class="d-flex">
                    <input type="text" name="query" class="form-control" placeholder="ابحث برقم الحجز أو المستخدم..."
                        value="<?php echo e($query ?? ''); ?>">

                    <select name="status" class="form-select ms-2" style="max-width: 200px" onchange="this.form.submit()">
                        <option value="">كل الحالات</option>
                        <option value="pending" <?php echo e(($status ?? '') === 'pending' ? 'selected' : ''); ?>>معلق</option>
                        <option value="confirmed" <?php echo e(($status ?? '') === 'confirmed' ? 'selected' : ''); ?>>مؤكد</option>
                        <option value="active" <?php echo e(($status ?? '') === 'active' ? 'selected' : ''); ?>>فعّال</option>
                        <option value="completed" <?php echo e(($status ?? '') === 'completed' ? 'selected' : ''); ?>>منتهي</option>
                        <option value="cancelled" <?php echo e(($status ?? '') === 'cancelled' ? 'selected' : ''); ?>>ملغي</option>
                    </select>

                    <button class="btn btn-primary ms-2">
                        <i class="fas fa-search"></i>
                    </button>
                </form>
            </div>

            <div class="card-body p-0">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>#</th>
                            <th>المعدة</th>
                            <th>المستأجر</th>
                            <th>الحالة</th>
                            <th>تاريخ الإنشاء</th>
                            <th class="text-center">إجراءات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td>#<?php echo e($booking->id); ?></td>
                                <td><?php echo e($booking->equipment->name ?? '-'); ?></td>
                                <td><?php echo e($booking->renter->first_name ?? '-'); ?></td>

                                
                                <td>
                                    <?php switch($booking->booking_status):
                                        case ('pending'): ?>
                                            <span class="badge bg-warning text-dark">معلق</span>
                                        <?php break; ?>

                                        <?php case ('confirmed'): ?>
                                            <span class="badge bg-info text-dark">مؤكد</span>
                                        <?php break; ?>

                                        <?php case ('active'): ?>
                                            <span class="badge bg-primary">قيد التنفيذ</span>
                                        <?php break; ?>

                                        <?php case ('completed'): ?>
                                            <span class="badge bg-success">منتهي</span>
                                        <?php break; ?>

                                        <?php case ('cancelled'): ?>
                                            <span class="badge bg-danger">ملغي</span>
                                        <?php break; ?>

                                        <?php default: ?>
                                            -
                                    <?php endswitch; ?>
                                </td>


                                <td><?php echo e($booking->created_at?->format('Y-m-d H:i')); ?></td>

                                <td class="text-center">
                                    <div class="dropdown action-dropdown">
                                        <button class="btn btn-light btn-sm dropdown-toggle" type="button"
                                            data-bs-toggle="dropdown">
                                            إجراءات
                                        </button>
                                        <ul class="dropdown-menu dropdown-menu-end">

                                            
                                            <li>
                                                <a class="dropdown-item"
                                                    href="<?php echo e(route('admin.bookings.show', $booking)); ?>">
                                                    <i class="fas fa-eye text-info"></i> تفاصيل الحجز
                                                </a>
                                            </li>

                                            
                                            <?php if(in_array($booking->booking_status, ['pending'])): ?>
                                                <li>
                                                    <a class="dropdown-item" href="#"
                                                        onclick="event.preventDefault(); document.getElementById('confirm-booking-<?php echo e($booking->id); ?>').submit();">
                                                        <i class="fas fa-check-circle text-success"></i> تأكيد الحجز
                                                    </a>
                                                </li>
                                                <form id="confirm-booking-<?php echo e($booking->id); ?>"
                                                    action="<?php echo e(route('admin.bookings.confirm', $booking)); ?>" method="POST"
                                                    class="d-none">
                                                    <?php echo csrf_field(); ?>
                                                </form>
                                            <?php endif; ?>

                                            
                                            <?php if(in_array($booking->booking_status, ['confirmed'])): ?>
                                                <li>
                                                    <a class="dropdown-item" href="#"
                                                        onclick="event.preventDefault(); document.getElementById('activate-booking-<?php echo e($booking->id); ?>').submit();">
                                                        <i class="fas fa-play text-primary"></i> تفعيل (بدء الإيجار)
                                                    </a>
                                                </li>
                                                <form id="activate-booking-<?php echo e($booking->id); ?>"
                                                    action="<?php echo e(route('admin.bookings.activate', $booking)); ?>"
                                                    method="POST" class="d-none">
                                                    <?php echo csrf_field(); ?>
                                                </form>
                                            <?php endif; ?>

                                            
                                            <?php if(in_array($booking->booking_status, ['active'])): ?>
                                                <li>
                                                    <a class="dropdown-item" href="#"
                                                        onclick="event.preventDefault(); document.getElementById('complete-booking-<?php echo e($booking->id); ?>').submit();">
                                                        <i class="fas fa-flag-checkered text-success"></i> إنهاء الحجز
                                                    </a>
                                                </li>
                                                <form id="complete-booking-<?php echo e($booking->id); ?>"
                                                    action="<?php echo e(route('admin.bookings.complete', $booking)); ?>"
                                                    method="POST" class="d-none">
                                                    <?php echo csrf_field(); ?>
                                                </form>
                                            <?php endif; ?>

                                            
                                            <?php if(!in_array($booking->booking_status, ['pending', 'cancelled'])): ?>
                                                <li>
                                                    <a class="dropdown-item" href="#"
                                                        onclick="event.preventDefault(); document.getElementById('hold-booking-<?php echo e($booking->id); ?>').submit();">
                                                        <i class="fas fa-pause-circle text-warning"></i> إعادة إلى معلّق
                                                    </a>
                                                </li>
                                                <form id="hold-booking-<?php echo e($booking->id); ?>"
                                                    action="<?php echo e(route('admin.bookings.hold', $booking)); ?>" method="POST"
                                                    class="d-none">
                                                    <?php echo csrf_field(); ?>
                                                </form>
                                            <?php endif; ?>

                                            
                                            <?php if($booking->booking_status !== 'cancelled'): ?>
                                                <li>
                                                    <a class="dropdown-item text-danger" href="#"
                                                        data-bs-toggle="modal"
                                                        data-bs-target="#cancelBookingModal<?php echo e($booking->id); ?>">
                                                        <i class="fas fa-times-circle"></i> إلغاء الحجز
                                                    </a>
                                                </li>
                                            <?php endif; ?>

                                            <li>
                                                <hr class="dropdown-divider">
                                            </li>

                                            
                                            <li>
                                                <a class="dropdown-item text-danger" href="#" data-bs-toggle="modal"
                                                    data-bs-target="#deleteBookingModal<?php echo e($booking->id); ?>">
                                                    <i class="fas fa-trash"></i> حذف الحجز
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </td>
                            </tr>

                            
                            <div class="modal fade" id="cancelBookingModal<?php echo e($booking->id); ?>" tabindex="-1"
                                aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <form action="<?php echo e(route('admin.bookings.cancel', $booking)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <div class="modal-header">
                                                <h5 class="modal-title">إلغاء الحجز #<?php echo e($booking->id); ?></h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                            </div>
                                            <div class="modal-body">
                                                <p>هل أنت متأكد من إلغاء هذا الحجز؟</p>
                                                <div class="mb-3">
                                                    <label class="form-label">سبب الإلغاء (اختياري)</label>
                                                    <textarea name="reason" class="form-control" rows="3"></textarea>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary"
                                                    data-bs-dismiss="modal">إغلاق</button>
                                                <button type="submit" class="btn btn-danger">تأكيد الإلغاء</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            
                            <div class="modal fade" id="deleteBookingModal<?php echo e($booking->id); ?>" tabindex="-1"
                                aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <form action="<?php echo e(route('admin.bookings.destroy', $booking)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <div class="modal-header">
                                                <h5 class="modal-title">حذف الحجز #<?php echo e($booking->id); ?></h5>
                                                <button type="button" class="btn-close"
                                                    data-bs-dismiss="modal"></button>
                                            </div>
                                            <div class="modal-body">
                                                <p>هل أنت متأكد من نقل هذا الحجز إلى سلة المحذوفات؟</p>
                                                <div class="alert alert-warning mb-0">
                                                    يمكن استرجاعه لاحقاً من سلة المحذوفات
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary"
                                                    data-bs-dismiss="modal">إلغاء</button>
                                                <button type="submit" class="btn btn-danger">نعم، حذف</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6" class="text-center p-4">لا توجد حجوزات.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>

                    </table>
                </div>


                <div class="card-footer">
                    <?php echo e($bookings->links()); ?>

                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Alhasan\Desktop\final\equipment-rental-project\resources\views/dashboard/bookings/index.blade.php ENDPATH**/ ?>