<?php $__env->startSection('title', $currentParent ? $currentParent->category_name : 'الفئات'); ?>

<?php $__env->startSection('content'); ?>

    <div class="page-head">
        <div class="page-head__bg" style="background-image: url(<?php echo e(asset('assets/home/img/bg/bg_categories.jpg')); ?>)">
            <div class="page-head__content" data-uk-parallax="y: 0, 100">
                <div class="uk-container">
                    <div class="header-icons"><span></span><span></span><span></span></div>
                    <div class="page-head__title">
                        <?php echo e($currentParent ? $currentParent->category_name : 'فئات الإيجار'); ?>

                    </div>
                    <div class="page-head__breadcrumb">
                        <ul class="uk-breadcrumb">
                            <li><a href="<?php echo e(route('home')); ?>">الصفحة الرئيسية</a></li>
                            <?php if($currentParent): ?>
                                <li>
                                    <a href="<?php echo e(route('categories')); ?>">فئات الإيجار</a>
                                </li>
                                <li><span><?php echo e($currentParent->category_name); ?></span></li>
                            <?php else: ?>
                                <li><span>فئات الإيجار</span></li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="page-content">
        <div class="uk-section-large uk-container">
            
            <?php if($currentParent): ?>
                <div class="uk-margin-bottom">
                    <a href="<?php echo e(route('categories')); ?>" class="uk-button uk-button-default">
                        <span data-uk-icon="arrow-right"></span> الرجوع إلى الفئات الرئيسية
                    </a>
                </div>
            <?php endif; ?>

            <div class="uk-grid uk-grid-medium uk-child-width-1-3@m uk-child-width-1-2@s" data-uk-grid>
                <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div>
                        <div class="category-item">
                            <a class="category-item__link uk-inline-clip uk-transition-toggle"
                               href="<?php echo e($category->children->count() ? route('categories', ['parent_id' => $category->id]) : route('equipments', ['category' => $category->id])); ?>"
                               tabindex="0">
                                <div class="category-item__media">
                                    <img src="<?php echo e(asset('storage/' . $category->image_url)); ?>"
                                         alt="<?php echo e($category->category_name); ?>" />

                                    <div class="uk-transition-fade">
                                        <div class="uk-overlay-primary uk-position-cover"></div>
                                        <div class="uk-position-center">
                                            <span data-uk-icon="icon: <?php echo e($category->children->count() ? 'folder' : 'plus'); ?>; ratio: 2"></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="category-item__title">
                                    <span><?php echo e($category->category_name); ?></span>
                                    <?php if($category->children->count()): ?>
                                        <small class="uk-text-meta d-block">(<?php echo e($category->children->count()); ?> قسم فرعي)</small>
                                    <?php endif; ?>
                                </div>
                            </a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="uk-width-1-1 uk-text-center">
                        <p>لا توجد فئات فرعية في هذا القسم.</p>
                    </div>
                <?php endif; ?>
            </div>

            <div class="uk-margin-top uk-text-center">
                <?php echo e($categories->links('pagination::bootstrap-5')); ?>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Alhasan\Desktop\final\equipment-rental-project\resources\views/frontend/categories.blade.php ENDPATH**/ ?>