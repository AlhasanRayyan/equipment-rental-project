<?php $__env->startSection('styles'); ?>
    <style>
        .action-dropdown .dropdown-menu {
            min-width: 200px;
            border-radius: 0.5rem;
            box-shadow: 0 .5rem 1rem rgba(0, 0, 0, .15);
        }

        .action-dropdown .dropdown-item {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 0.5rem 1rem;
        }

        .action-dropdown .dropdown-item i {
            width: 18px;
            text-align: center;
            opacity: 0.7;
        }

        .avatar-placeholder {
            width: 40px;
            height: 40px;
            background-color: #4e73df;
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 1.1rem;
            border-radius: 50%;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="h3 mb-0 text-gray-800">
                <?php if(isset($isArchivedPage)): ?>
                    الشكاوى المؤرشفة (المحلولة)
                <?php else: ?>
                    إدارة الشكاوى والاستفسارات
                <?php endif; ?>
            </h1>
            <div>
                <a href="<?php echo e(route('admin.complaints.index')); ?>"
                    class="btn   <?php echo e(!isset($isArchivedPage) ? 'btn-primary' : 'btn-outline-primary'); ?>">
                    الشكاوى الحالية
                </a>
                <a href="<?php echo e(route('admin.complaints.archived')); ?>"
                    class="btn   <?php echo e(isset($isArchivedPage) ? 'btn-primary' : 'btn-outline-primary'); ?>">
                    الشكاوى المؤرشفة
                </a>
                <a href="<?php echo e(route('admin.complaints.trash')); ?>" class="btn   btn-outline-danger">
                    <i class="fas fa-trash-alt"></i> سلة المحذوفات
                </a>
            </div>
        </div>


        <?php echo $__env->make('partials.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="card shadow">
            <div class="card-header py-3">
                <div class="d-flex flex-column flex-md-row justify-content-between align-items-center">
                    <h6 class="m-0 fw-bold text-primary mb-2 mb-md-0">
                        <i class="fas fa-headset me-2"></i>قائمة الشكاوى (<?php echo e($complaints->total()); ?>)
                    </h6>
                    <form id="complaintFilterForm"
                        action="<?php echo e(isset($isArchivedPage) ? route('admin.complaints.archived') : route('admin.complaints.index')); ?>"
                        method="GET" class="d-flex flex-wrap justify-content-end" style="max-width: 800px; width: 100%;">

                        <div class="input-group mb-2 mb-md-0 me-2" style="flex: 1 1 250px;">
                            <input type="text" name="query" class="form-control"
                                placeholder="ابحث في المحتوى أو المرسل..." value="<?php echo e($query ?? ''); ?>">
                            <button type="submit" class="btn btn-primary btn btn-primary">
                                <i class="fas fa-search "></i>
                            </button>

                        </div>


                        <?php if (! (isset($isArchivedPage))): ?>
                            <select name="status" id="statusFilterSelect" class="form-select me-2 mb-2 mb-md-0"
                                style="width: auto;">
                                <option value="all" <?php echo e($statusFilter == 'all' ? 'selected' : ''); ?>>جميع الحالات</option>
                                <option value="unread" <?php echo e($statusFilter == 'unread' ? 'selected' : ''); ?>>غير مقروءة</option>
                                <option value="read" <?php echo e($statusFilter == 'read' ? 'selected' : ''); ?>>مقروءة</option>
                                <option value="resolved" <?php echo e($statusFilter == 'resolved' ? 'selected' : ''); ?>>تم الحل</option>
                            </select>
                        <?php endif; ?>


                        <select name="type" id="typeFilterSelect" class="form-select me-2 mb-2 mb-md-0"
                            style="width: auto;">
                            <option value="all" <?php echo e($typeFilter == 'all' ? 'selected' : ''); ?>>جميع الأنواع</option>
                            <?php $__currentLoopData = $messageTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($type); ?>" <?php echo e($typeFilter == $type ? 'selected' : ''); ?>>
                                    <?php echo e(ucfirst($type)); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>


                        <?php if($query || $statusFilter != 'unread' || $typeFilter != 'all'): ?>
                            <a href="<?php echo e(route('admin.complaints.index')); ?>" class="btn btn-secondary ms-2 mb-2 mb-md-0"
                                title="إلغاء البحث والفلاتر"><i class="fas fa-times"></i></a>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>المرسل</th>
                                <th>الموضوع/المحتوى</th>
                                <th>النوع</th>
                                <th>الحالة</th>
                                <th>تاريخ الإرسال</th>
                                <th class="text-center">الإجراءات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $complaints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $complaint): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <div class="avatar-placeholder me-3">
                                                <span><?php echo e(mb_substr($complaint->sender->first_name ?? 'U', 0, 1)); ?></span>
                                            </div>
                                            <div>
                                                <div class="fw-bold"><?php echo e($complaint->sender->first_name ?? 'مستخدم محذوف'); ?>

                                                    <?php echo e($complaint->sender->last_name ?? ''); ?></div>
                                                <div class="text-muted small"><?php echo e($complaint->sender->email ?? 'N/A'); ?>

                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td><?php echo e(Str::limit($complaint->content, 60)); ?></td>
                                    <td><span class="badge bg-secondary"><?php echo e(ucfirst($complaint->message_type)); ?></span>
                                    </td>
                                    <td>
                                        
                                        <?php if($complaint->is_resolved): ?>
                                            <span class="badge bg-success">تم الحل</span>
                                        <?php elseif($complaint->is_read): ?>
                                            <span class="badge bg-primary">مقروءة</span>
                                        <?php else: ?>
                                            <span class="badge bg-warning text-dark">جديدة</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($complaint->created_at->diffForHumans()); ?></td>
                                    <td class="text-center">
                                        <div class="dropdown action-dropdown">
                                            <button class="btn btn-light   dropdown-toggle" type="button"
                                                data-bs-toggle="dropdown">إجراءات</button>
                                            <ul class="dropdown-menu dropdown-menu-end">
                                                <li><a class="dropdown-item"
                                                        href="<?php echo e(route('admin.complaints.show', $complaint)); ?>"><i
                                                            class="fas fa-eye text-primary"></i> عرض التفاصيل</a></li>
                                                <?php if(!$complaint->is_read): ?>
                                                    <li><a class="dropdown-item" href="#"
                                                            onclick="event.preventDefault(); document.getElementById('mark-read-form-<?php echo e($complaint->id); ?>').submit();"><i
                                                                class="fas fa-check-double text-success"></i> تمييز
                                                            كمقروءة</a></li>
                                                    <form id="mark-read-form-<?php echo e($complaint->id); ?>"
                                                        action="<?php echo e(route('admin.complaints.markAsRead', $complaint)); ?>"
                                                        method="POST" class="d-none"><?php echo csrf_field(); ?></form>
                                                <?php endif; ?>
                                                <?php if(!$complaint->is_resolved): ?>
                                                    
                                                    <li><a class="dropdown-item" href="#"
                                                            onclick="event.preventDefault(); document.getElementById('resolve-form-<?php echo e($complaint->id); ?>').submit();"><i
                                                                class="fas fa-check-circle text-success"></i> وضع علامة تم
                                                            الحل</a></li>
                                                    <form id="resolve-form-<?php echo e($complaint->id); ?>"
                                                        action="<?php echo e(route('admin.complaints.resolve', $complaint)); ?>"
                                                        method="POST" class="d-none"><?php echo csrf_field(); ?></form>
                                                <?php endif; ?>
                                                <li>
                                                    <hr class="dropdown-divider">
                                                </li>
                                                <li><a class="dropdown-item" href="#" data-bs-toggle="modal"
                                                        data-bs-target="#deleteComplaintModal<?php echo e($complaint->id); ?>"><i
                                                            class="fas fa-trash text-danger"></i> حذف الشكوى</a></li>
                                            </ul>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6" class="text-center p-4">لا توجد شكاوى أو استفسارات حالياً.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <div class="d-flex justify-content-center mt-3"><?php echo e($complaints->links()); ?></div>
            </div>
        </div>
    </div>

    <?php $__currentLoopData = $complaints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $complaint): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <div class="modal fade" id="deleteComplaintModal<?php echo e($complaint->id); ?>" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <form action="<?php echo e(route('admin.complaints.destroy', $complaint)); ?>" method="POST">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <div class="modal-header">
                            <h5 class="modal-title">تأكيد حذف الشكوى</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <p>هل أنت متأكد من حذف هذه الشكوى/الاستفسار من
                                <strong><?php echo e($complaint->sender->first_name ?? 'مستخدم'); ?></strong>؟
                            </p>
                            <div class="alert alert-danger" role="alert">
                                سيتم حذف هذه الشكوى بشكل دائم ولن يمكن استرجاعها.
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                            <button type="submit" class="btn btn-danger">حذف</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // تهيئة Tooltips
            var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
            var tooltipList = tooltipTriggerList.map(function(tooltipTriggerEl) {
                return new bootstrap.Tooltip(tooltipTriggerEl)
            });

            // **الـ JavaScript لجعل الفلاتر تعمل تلقائياً**
            const complaintFilterForm = document.getElementById('complaintFilterForm');
            const statusFilterSelect = document.getElementById('statusFilterSelect');
            const typeFilterSelect = document.getElementById('typeFilterSelect');

            if (statusFilterSelect) {
                statusFilterSelect.addEventListener('change', function() {
                    complaintFilterForm.submit();
                });
            }
            if (typeFilterSelect) {
                typeFilterSelect.addEventListener('change', function() {
                    complaintFilterForm.submit();
                });
            }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Alhasan\Desktop\final\equipment-rental-project\resources\views/dashboard/complaints/index.blade.php ENDPATH**/ ?>