<?php if($favorites->isEmpty()): ?>
    <p class="uk-text-center">لا توجد معدات في المفضلة.</p>
<?php else: ?>
<div class="uk-grid-small uk-child-width-1-2@s uk-child-width-1-3@m" data-uk-grid>
    <?php $__currentLoopData = $favorites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fav): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div>
            <div class="uk-card uk-card-default uk-card-body uk-text-center">
                <h5 class="uk-card-title"><?php echo e($fav->equipment->name ?? 'تم حذف المعدة'); ?></h5>
                <p>الفئة: <?php echo e($fav->equipment->category ?? '-'); ?></p>
                <button class="uk-button uk-button-danger uk-button-small">إزالة</button>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php endif; ?>
<?php /**PATH C:\Users\Alhasan\Desktop\final\equipment-rental-project\resources\views/frontend/user/sections/favorites.blade.php ENDPATH**/ ?>