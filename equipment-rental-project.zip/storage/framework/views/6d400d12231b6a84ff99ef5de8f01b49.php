<?php $__env->startSection('title', 'نتائج البحث عن المعدات'); ?>

<?php $__env->startSection('content'); ?>

    <div class="page-head">
        <div class="page-head__bg" style="background-image: url(<?php echo e(asset('assets/home/img/bg/bg_blog.jpg')); ?>)">
            <div class="page-head__content" data-uk-parallax="y: 0, 100">
                <div class="uk-container">
                    <div class="header-icons"><span></span><span></span><span></span></div>
                    <div class="page-head__title">المعدات</div>
                    <div class="page-head__breadcrumb">
                        <ul class="uk-breadcrumb">
                            <li><a href="<?php echo e(route('home')); ?>">الصفحة الرئيسية</a></li> 
                            <li><span>المعدات</span></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- start search part - تم نقل كود البحث هنا من home.blade.php ليظهر في صفحة النتائج أيضاً -->
    <div class="section-find section-find1 uk-section-large uk-background-muted"> 
        <div class="uk-container">
            <div class="uk-card uk-card-default uk-card-body uk-box-shadow-large uk-border-rounded"> 
                <div class="find-box">
                    <div class="find-box__title uk-text-center uk-h2 uk-margin-medium-bottom"> <span>اعثر على المعدات
                            المناسبة</span></div>
                    <div class="find-box__form">
                        <form action="<?php echo e(route('equipments')); ?>" method="GET">
                            <div class="uk-grid uk-grid-medium uk-child-width-1-1 uk-child-width-1-3@m" data-uk-grid>
                                
                                <div>
                                    <label class="uk-form-label" for="filter-category">الصنف</label>
                                    <div class="uk-form-controls">
                                        <div class="uk-inline uk-width-1-1"> 
                                            <span class="uk-form-icon" data-uk-icon="icon: chevron-down"></span>
                                            <select class="uk-select uk-form-large" id="filter-category" name="category">
                                                <option value="">إختر الصنف</option>
                                                <?php $__currentLoopData = $equipmentCategories->whereNull('parent_id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parentCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($parentCategory->id); ?>"
                                                        <?php echo e((isset($categoryId) && $categoryId == $parentCategory->id) ? 'selected' : ''); ?>>
                                                        <?php echo e($parentCategory->category_name); ?>

                                                    </option>
                                                    <?php $__currentLoopData = $parentCategory->children->where('is_active', true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($subCategory->id); ?>"
                                                            <?php echo e((isset($categoryId) && $categoryId == $subCategory->id) ? 'selected' : ''); ?>>
                                                            &nbsp;&nbsp;&nbsp;&nbsp;— <?php echo e($subCategory->category_name); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                
                                <div>
                                    <label class="uk-form-label" for="filter-location">الموقع</label>
                                    <div class="uk-form-controls">
                                        <div class="uk-inline uk-width-1-1"> 
                                            <span class="uk-form-icon" data-uk-icon="icon: chevron-down"></span>
                                            <select class="uk-select uk-form-large" id="filter-location" name="location">
                                                <option value="">إختر موقعك الحالي</option>
                                                <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($loc); ?>"
                                                        <?php echo e((isset($location) && $location == $loc) ? 'selected' : ''); ?>>
                                                        <?php echo e($loc); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                
                                <div>
                                    <label class="uk-form-label" for="filter-query">اسم المعدة</label>
                                    <div class="uk-form-controls uk-inline uk-width-1-1">
                                        <span class="uk-form-icon uk-form-icon-flip" data-uk-icon="icon: search"></span>
                                        <input class="uk-input uk-form-large" id="filter-query" type="text"
                                            name="query" placeholder="اسم المعدة" value="<?php echo e($query ?? ''); ?>">
                                    </div>
                                </div>
                            </div>

                            
                            <div class="uk-grid uk-grid-medium uk-child-width-1-1 uk-child-width-1-2@m uk-margin-top" data-uk-grid>
                                <div>
                                    <label class="uk-form-label" for="filter-min-rate">الحد الأدنى للسعر اليومي</label>
                                    <div class="uk-form-controls">
                                        <input class="uk-input uk-form-large" id="filter-min-rate" type="number"
                                            step="0.01" name="min_daily_rate" placeholder="أقل سعر"
                                            value="<?php echo e($minDailyRate ?? ''); ?>">
                                    </div>
                                </div>
                                <div>
                                    <label class="uk-form-label" for="filter-max-rate">الحد الأقصى للسعر اليومي</label>
                                    <div class="uk-form-controls">
                                        <input class="uk-input uk-form-large" id="filter-max-rate" type="number"
                                            step="0.01" name="max_daily_rate" placeholder="أقصى سعر"
                                            value="<?php echo e($maxDailyRate ?? ''); ?>">
                                    </div>
                                </div>
                            </div>

                            <div class="uk-margin-large-top uk-text-center">
                                <button type="submit"
                                    class="uk-button uk-button-primary uk-button-large uk-margin-small-right"><span>البحث عن
                                        المعدات</span></button>
                                <a href="<?php echo e(route('equipments')); ?>"
                                    class="uk-button uk-button-default uk-button-large"><span>إعادة تعيين الفلاتر</span></a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- end search part -->

    <div class="page-content">
        <div class="uk-section-large uk-container">
            <div class="uk-grid uk-grid-medium uk-child-width-1-3@m uk-child-width-1-2@s" data-uk-grid>
                <?php $__empty_1 = true; $__currentLoopData = $equipments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equipment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div>
                        <div class="blog-item"> 
                            <div class="blog-item__media">
                                <a href="<?php echo e(route('equipments.show', $equipment->id)); ?>"> 
                                    
                                    <?php if($equipment->images->count() > 0): ?>
                                        <img src="<?php echo e(asset('storage/' . $equipment->images->first()->image_url)); ?>"
                                             alt="<?php echo e($equipment->name); ?>"
                                             data-uk-img> 
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('assets/home/img/equipment-default.jpg')); ?>"
                                             alt="صورة افتراضية للمعدة"
                                             data-uk-img>
                                    <?php endif; ?>
                                </a>
                                <div class="blog-item__category"><?php echo e($equipment->category->category_name ?? 'غير مصنف'); ?></div>
                            </div>
                            <div class="blog-item__body">
                                <div class="blog-item__info">
                                    <div class="blog-item__date"><?php echo e($equipment->created_at->format('d M, Y')); ?></div>
                                    <div class="blog-item__author"> بواسطة <a
                                            href="#"><?php echo e($equipment->owner->name ?? 'غير معروف'); ?></a></div>
                                </div>
                                <div class="blog-item__title"><?php echo e($equipment->name); ?></div>
                                <div class="blog-item__intro"><?php echo e(Str::limit($equipment->description, 100)); ?></div>
                                
                                <div class="rating">
                                    <?php for($i = 1; $i <= 5; $i++): ?>
                                        <span class="uk-icon" data-uk-icon="icon: star<?php echo e($equipment->average_rating >= $i ? '' : '-o'); ?>; ratio: 0.8"></span>
                                    <?php endfor; ?>
                                    
                                </div>
                            </div>
                            <div class="blog-item__bottom">
                                <a class="link-more" href="<?php echo e(route('equipments.show', $equipment->id)); ?>">
                                    <span>إقرأ أكثر</span>
                                    <img class="ukos" src="<?php echo e(asset('assets/home/img/icons/arrow.svg')); ?>" alt="arrow"
                                        data-uk-svg>
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="uk-width-1-1"> 
                        <div class="uk-alert-warning uk-text-center" data-uk-alert>
                            <a class="uk-alert-close" data-uk-close></a>
                            <p>لا توجد معدات مطابقة لمعايير البحث حالياً.</p>
                        </div>
                    </div>
                <?php endif; ?>
            </div>

        
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Alhasan\Desktop\final\equipment-rental-project\resources\views/frontend/equipments.blade.php ENDPATH**/ ?>