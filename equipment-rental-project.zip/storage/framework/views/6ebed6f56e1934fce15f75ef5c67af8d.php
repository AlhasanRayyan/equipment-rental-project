
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    // أيقونة FontAwesome، مثال: "fas fa-users"
    'icon',

    // عنوان البطاقة
    'title',

    // القيمة المراد عرضها
    'value',

    // لون البطاقة: primary, success, info, warning, danger (افتراضي 'primary')
    'color' => 'primary',

    // بادئة قبل الرقم (مثلاً $)
    'prefix' => null,

    // سطر صغير تحت الرقم
    'subtitle' => null,

    // بادج صغيرة جنب العنوان
    'badge' => null,
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    // أيقونة FontAwesome، مثال: "fas fa-users"
    'icon',

    // عنوان البطاقة
    'title',

    // القيمة المراد عرضها
    'value',

    // لون البطاقة: primary, success, info, warning, danger (افتراضي 'primary')
    'color' => 'primary',

    // بادئة قبل الرقم (مثلاً $)
    'prefix' => null,

    // سطر صغير تحت الرقم
    'subtitle' => null,

    // بادج صغيرة جنب العنوان
    'badge' => null,
]); ?>
<?php foreach (array_filter(([
    // أيقونة FontAwesome، مثال: "fas fa-users"
    'icon',

    // عنوان البطاقة
    'title',

    // القيمة المراد عرضها
    'value',

    // لون البطاقة: primary, success, info, warning, danger (افتراضي 'primary')
    'color' => 'primary',

    // بادئة قبل الرقم (مثلاً $)
    'prefix' => null,

    // سطر صغير تحت الرقم
    'subtitle' => null,

    // بادج صغيرة جنب العنوان
    'badge' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="card border-left-<?php echo e($color); ?> shadow h-100 py-2">
    <div class="card-body">
        <div class="row no-gutters align-items-center">
            <div class="col mr-2">
                
                <div class="d-flex align-items-center gap-2 mb-1">
                    <div class="text-xs font-weight-bold text-<?php echo e($color); ?> text-uppercase">
                        <?php echo e($title); ?>

                    </div>

                    <?php if($badge): ?>
                        <span class="badge bg-danger small">
                            <?php echo e($badge); ?>

                        </span>
                    <?php endif; ?>
                </div>

                
                <div class="h5 mb-0 font-weight-bold text-gray-800">
                    <?php if($prefix): ?><?php echo e($prefix); ?><?php endif; ?> <?php echo e($value); ?>

                </div>

                
                <?php if($subtitle): ?>
                    <div class="small text-muted mt-1">
                        <?php echo e($subtitle); ?>

                    </div>
                <?php endif; ?>
            </div>

            
            <div class="col-auto">
                <i class="<?php echo e($icon); ?> fa-2x text-gray-300"></i>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\Alhasan\Desktop\final\equipment-rental-project\resources\views/components/stats-card.blade.php ENDPATH**/ ?>