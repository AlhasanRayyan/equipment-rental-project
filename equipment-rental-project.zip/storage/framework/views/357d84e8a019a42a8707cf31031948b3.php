<?php $__env->startSection('styles'); ?>
    <style>
        .avatar-lg-placeholder {
            width: 80px;
            height: 80px;
            background-color: #4e73df;
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 2rem;
            border-radius: 50%;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="h3 mb-0 text-gray-800">تفاصيل الشكوى/الاستفسار</h1>
            <a href="<?php echo e(route('admin.complaints.index')); ?>" class="btn btn-secondary shadow-sm">
                <i class="fas fa-arrow-right fa-sm me-2"></i>العودة للشكاوى
            </a>
        </div>

        <?php echo $__env->make('partials.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="card shadow mb-4">
            <div class="card-header py-3 d-flex justify-content-between align-items-center">
                <h6 class="m-0 fw-bold text-primary">
                    <i class="fas fa-info-circle me-2"></i>معلومات الشكوى #<?php echo e($message->id); ?>

                </h6>
                <div class="dropdown">
                    <button class="btn btn-light btn-sm dropdown-toggle" type="button"
                        data-bs-toggle="dropdown">إجراءات</button>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <?php if(!$message->is_read): ?>
                            <li><a class="dropdown-item" href="#"
                                    onclick="event.preventDefault(); document.getElementById('mark-read-form-<?php echo e($message->id); ?>').submit();"><i
                                        class="fas fa-check-double text-success"></i> تمييز كمقروءة</a></li>
                            <form id="mark-read-form-<?php echo e($message->id); ?>"
                                action="<?php echo e(route('admin.complaints.markAsRead', $message)); ?>" method="POST" class="d-none">
                                <?php echo csrf_field(); ?></form>
                        <?php endif; ?>
                        <?php if(!$message->is_resolved): ?>
                            
                            <li><a class="dropdown-item" href="#"
                                    onclick="event.preventDefault(); document.getElementById('resolve-form-<?php echo e($message->id); ?>').submit();"><i
                                        class="fas fa-check-circle text-success"></i> وضع علامة تم الحل</a></li>
                            <form id="resolve-form-<?php echo e($message->id); ?>"
                                action="<?php echo e(route('admin.complaints.resolve', $message)); ?>" method="POST" class="d-none">
                                <?php echo csrf_field(); ?></form>
                        <?php endif; ?>
                        <li>
                            <hr class="dropdown-divider">
                        </li>
                        <li><a class="dropdown-item text-danger" href="#" data-bs-toggle="modal"
                                data-bs-target="#deleteComplaintModal<?php echo e($message->id); ?>"><i class="fas fa-trash"></i> حذف
                                الشكوى</a></li>
                    </ul>
                </div>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="d-flex align-items-center mb-4">
                            <div class="avatar-lg-placeholder me-4">
                                <span><?php echo e(mb_substr($message->sender->first_name ?? 'U', 0, 1)); ?></span>
                            </div>
                            <div>
                                <h5 class="mb-0"><?php echo e($message->sender->first_name ?? 'مستخدم محذوف'); ?>

                                    <?php echo e($message->sender->last_name ?? ''); ?></h5>
                                <p class="text-muted mb-0"><?php echo e($message->sender->email ?? 'N/A'); ?></p>
                                <p class="text-muted small mb-0">تاريخ الإرسال:
                                    <?php echo e($message->created_at->format('Y-m-d H:i')); ?>

                                    (<?php echo e($message->created_at->diffForHumans()); ?>)</p>
                            </div>
                        </div>

                        <hr>

                        <div class="mb-4">
                            <h6>نوع الرسالة: <span class="badge bg-info"><?php echo e(ucfirst($message->message_type)); ?></span></h6>
                            <h6>الحالة:
                                <?php if($message->is_resolved): ?>
                                    
                                    <span class="badge bg-success">تم الحل</span>
                                <?php elseif($message->is_read): ?>
                                    <span class="badge bg-primary">مقروءة</span>
                                <?php else: ?>
                                    <span class="badge bg-warning text-dark">جديدة</span>
                                <?php endif; ?>
                            </h6>
                            <?php if($message->booking): ?>
                                <h6>مرتبطة بالحجز رقم: <a href=""  
                                         <p class="text-muted small">المعدة:
                                        <?php echo e($message->booking->equipment->name ?? 'N/A'); ?></p>
                            <?php endif; ?>
                        </div>

                        <div class="mb-4 p-3 bg-light rounded">
                            <h5 class="text-primary mb-3">محتوى الشكوى/الاستفسار:</h5>
                            <p class="lead"><?php echo nl2br(e($message->content)); ?></p>
                        </div>

                        
                        

                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <div class="modal fade" id="deleteComplaintModal<?php echo e($message->id); ?>" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form action="<?php echo e(route('admin.complaints.destroy', $message)); ?>" method="POST">
                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                    <div class="modal-header">
                        <h5 class="modal-title">تأكيد حذف الشكوى</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <p>هل أنت متأكد من حذف هذه الشكوى/الاستفسار من
                            <strong><?php echo e($message->sender->first_name ?? 'مستخدم'); ?></strong>؟
                        </p>
                        <div class="alert alert-danger" role="alert">
                            سيتم حذف هذه الشكوى بشكل دائم ولن يمكن استرجاعها.
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                        <button type="submit" class="btn btn-danger">حذف</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // تهيئة Tooltips
            var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
            var tooltipList = tooltipTriggerList.map(function(tooltipTriggerEl) {
                return new bootstrap.Tooltip(tooltipTriggerEl)
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Alhasan\Desktop\final\equipment-rental-project\resources\views/dashboard/complaints/show.blade.php ENDPATH**/ ?>