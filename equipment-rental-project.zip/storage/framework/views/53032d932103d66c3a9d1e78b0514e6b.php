

<?php $__env->startSection('title', 'إضافة معدة جديدة'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-head">
    <div class="page-head__bg" style="background-image: url(<?php echo e(asset('assets/home/img/bg/bg_contacts.jpg')); ?>)">
        <div class="page-head__content" data-uk-parallax="y: 0, 100">
            <div class="uk-container">
                <div class="header-icons"><span></span><span></span><span></span></div>
                <div class="page-head__title">إضافة معدة جديدة</div>
                <div class="page-head__breadcrumb">
                    <ul class="uk-breadcrumb">
                        <li><a href="<?php echo e(route('home')); ?>">الصفحة الرئيسية</a></li>
                        <li><span>إضافة معدة</span></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="page-content">
    <div class="uk-section-large uk-container">
        <div class="contacts-block">
            <div class="uk-grid uk-grid-collapse" data-uk-grid>
                <div class="uk-width-3-3@m">
                    <div class="block-form">
                        <div class="section-title">
                            <div class="uk-h2">إضافة البيانات</div>
                        </div>
                        <div class="section-content">
                            <p>يجب عليك إضافة بيانات صحيحة ودقيقة</p>

                            
                            <form action="<?php echo e(route('equipments.store')); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="uk-grid uk-grid-small uk-child-width-1-2@s" data-uk-grid>
                                    
                                    <div>
                                        <input name="name" class="uk-input uk-form-large" type="text" placeholder="اسم المعدة *" value="<?php echo e(old('name')); ?>" required>
                                    </div>

                                    <div>
                                        <select name="category_id" class="uk-select uk-form-large" required>
                                            <option value="">إختر الفئة</option>
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div>
                                        <input name="location_address" class="uk-input uk-form-large" type="text" placeholder="الموقع *" value="<?php echo e(old('location_address')); ?>" required>
                                    </div>

                                    <div><input name="daily_rate" class="uk-input uk-form-large" type="number" step="0.01" placeholder="سعر الإيجار اليومي *" value="<?php echo e(old('daily_rate')); ?>"></div>
                                    <div><input name="weekly_rate" class="uk-input uk-form-large" type="number" step="0.01" placeholder="سعر الإيجار الأسبوعي *" value="<?php echo e(old('weekly_rate')); ?>"></div>
                                    <div><input name="monthly_rate" class="uk-input uk-form-large" type="number" step="0.01" placeholder="سعر الإيجار الشهري *" value="<?php echo e(old('monthly_rate')); ?>"></div>

                                    <div><input name="deposit_amount" class="uk-input uk-form-large" type="number" step="0.01" placeholder="قيمة الإيداع *" value="<?php echo e(old('deposit_amount')); ?>"></div>

                                    <div>
                                        <select name="has_gps_tracker" class="uk-select uk-form-large">
                                            <option value="0">لا يوجد جهاز تتبع</option>
                                            <option value="1">يوجد جهاز تتبع</option>
                                        </select>
                                    </div>

                                    <div class="uk-width-1-1">
                                        <label class="custum-file-upload">
                                            <div class="text"><span>اضغط لإضافة الصور</span></div>
                                            <div class="icon"><i class="fas fa-upload"></i></div>
                                            <input type="file" name="images[]" multiple>
                                        </label>
                                    </div>

                                    <div class="uk-width-1-1">
                                        <textarea name="description" class="uk-textarea uk-form-large" placeholder="الوصف"><?php echo e(old('description')); ?></textarea>
                                    </div>

                                    <div>
                                        <button class="uk-button uk-button-large" type="submit">
                                            <span>إضافة</span>
                                            <img src="<?php echo e(asset('assets/home/img/icons/arrow.svg')); ?>" alt="arrow" data-uk-svg>
                                        </button>
                                    </div>

                                </div>
                            </form>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Alhasan\Desktop\final\equipment-rental-project\resources\views/frontend/equipments/create.blade.php ENDPATH**/ ?>