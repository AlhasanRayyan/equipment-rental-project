

<?php $__env->startSection('title', 'معدات المستخدم'); ?>

<?php $__env->startSection('content'); ?>
    <main class="page-main">
        <div class="page-head">
            <div class="page-head__bg" style="background-image: url(<?php echo e(asset('assets/home/img/bg/bg_blog.jpg')); ?>)">
                <div class="page-head__content" data-uk-parallax="y: 0, 100">
                    <div class="uk-container">
                        <div class="header-icons"><span></span><span></span><span></span></div>
                        <div class="page-head__title">معدات المالك</div>
                    </div>
                </div>
            </div>
        </div>

        
        <div class="section-find section-find1">
            <div class="uk-container">
                <div class="find-box">
                    <div class="find-box__title"><span>ابحث في معداتك</span></div>
                    <div class="find-box__form">
                        <form action="<?php echo e(route('owner.equipments.search')); ?>" method="GET">
                            <div class="uk-grid uk-grid-medium uk-flex-middle uk-child-width-1-3@m uk-child-width-1-2@s"
                                data-uk-grid>
                                <div>
                                    <div class="uk-inline uk-width-1-1">
                                        <select class="uk-select uk-form-large" name="category">
                                            <option value="">اختر الفئة</option>
                                            <?php $__currentLoopData = $categories->whereNull('parent_id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($parent->id); ?>"><?php echo e($parent->category_name); ?></option>
                                                <?php $__currentLoopData = $parent->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($child->id); ?>">— <?php echo e($child->category_name); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>

                                        <span class="uk-form-icon"><img src="<?php echo e(asset('assets/home/img/icons/truck.svg')); ?>"
                                                alt="truck" data-uk-svg></span>
                                    </div>
                                </div>
                                <div>
                                    <div class="uk-inline uk-width-1-1">
                                        <input class="uk-input uk-form-large" name="q" type="text"
                                            placeholder="اسم المعدة">
                                        <span class="uk-form-icon"><img
                                                src="<?php echo e(asset('assets/home/img/icons/derrick.svg')); ?>" alt="derrick"
                                                data-uk-svg></span>
                                    </div>
                                </div>
                                <div>
                                    <input class="main-input uk-input uk-form-large uk-width-1-1" type="submit"
                                        value="ابحث هنا">
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        
        <div class="page-content">
            <div class="uk-section-large uk-container">
                <div class="uk-grid uk-grid-medium uk-child-width-1-3@m uk-child-width-1-2@s" data-uk-grid>
                    <?php $__empty_1 = true; $__currentLoopData = $equipments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equipment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div>
                            <div class="blog-item">
                                <div class="blog-item__media">
                                    <a href="<?php echo e(route('equipments.show', $equipment->id)); ?>">
                                        <?php if($equipment->images->isNotEmpty()): ?>
                                            <img src="<?php echo e(asset('storage/' . $equipment->images->first()->image_url)); ?>"
                                                alt="<?php echo e($equipment->name); ?>" class="equipment-img">
                                        <?php else: ?>
                                            <img src="<?php echo e(asset('images/default-equipment.png')); ?>" alt="No Image"
                                                class="equipment-img">
                                        <?php endif; ?>
                                    </a>
                                    <div class="blog-item__category"><?php echo e($equipment->status); ?></div>
                                </div>
                                <div class="blog-item__body">
                                    <div class="blog-item__info">
                                        <div class="blog-item__date"><?php echo e($equipment->created_at->format('d M')); ?></div>
                                    </div>
                                    <div class="blog-item__title"><?php echo e($equipment->name); ?></div>
                                    <div class="blog-item__intro"><?php echo e(Str::limit($equipment->description, 60)); ?></div>
                                    <div class="rating">
                                        <?php for($i = 1; $i <= 5; $i++): ?>
                                            <input value="<?php echo e($i); ?>" name="rate<?php echo e($equipment->id); ?>"
                                                id="star<?php echo e($i); ?>-<?php echo e($equipment->id); ?>" type="radio"
                                                <?php echo e($equipment->rating == $i ? 'checked' : ''); ?>>
                                            <label for="star<?php echo e($i); ?>-<?php echo e($equipment->id); ?>"></label>
                                        <?php endfor; ?>
                                    </div>
                                </div>
                                <div class="blog-item__bottom">
                                    <a class="link-more" href="<?php echo e(route('owner.equipments.edit', $equipment->id)); ?>">
                                        <span>تعديل</span>
                                        <img class="makos" src="<?php echo e(asset('assets/home/img/icons/arrow.svg')); ?>"
                                            alt="arrow" data-uk-svg>
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="uk-text-center uk-width-1-1">لا توجد معدات مضافة بعد.</p>
                    <?php endif; ?>
                </div>

                
                <div class="uk-flex uk-flex-center uk-margin-large-top">
                    <?php echo e($equipments->links('pagination::bootstrap-5')); ?>

                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Alhasan\Desktop\final\equipment-rental-project\resources\views/user/my_equipments.blade.php ENDPATH**/ ?>