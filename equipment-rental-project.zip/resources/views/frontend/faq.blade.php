<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>الأسئلة الشائعة</title>
    <link rel="stylesheet" href="{{ asset('assets/home/css/style.css') }}">
</head>
<body>
    <div class="uk-container" style="margin: 100px auto; text-align: center;">
        <h1>الأسئلة الشائعة</h1>
        <p>سيتم إضافة الأسئلة الشائعة قريبًا...</p>
    </div>
</body>
</html>
