<footer class="footer pt-3">
    <div class="container-fluid">
        <div class="row align-items-center justify-content-center"> 
            <div class="col-md-6 text-center"> 
                <p class="mb-0 text-muted">
                    &copy;
                    <script>
                        document.write(new Date().getFullYear())
                    </script>
                    <span class="font-weight-bold">نظام تأجير المعدات. جميع الحقوق محفوظة.</span> {{-- تم تغيير النص --}}
                </p>
            </div>
        </div>
    </div>
</footer>